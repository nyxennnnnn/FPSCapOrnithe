# Custom FPS Cap — Minecraft 1.8.9 / Ornithe

A minimal client-side port of Patcher's **Custom FPS Limit** feature. It does not include any other Patcher features and does not depend on Forge, Essential, or Patcher.

## Configuration

Launch the game once with the mod installed. It creates:

`<Minecraft game directory>/config/custom-fps-cap.properties`

Edit the file:

```properties
limit=600
```

- `0`: use Minecraft's normal FPS setting.
- `1` or higher: use that custom FPS limit. The default is `600`.

Restart Minecraft after changing the value.

## Build

This project uses the official Ornithe mod template toolchain (Fabric Loom + Ploceus + Feather mappings). Use a Java 21 development environment and run:

```bash
gradle build
```

The remapped mod JAR is written to `build/libs/`.

## Notes

- Minecraft target: 1.8.9
- Loader: Ornithe (Fabric)
- Client-side only
- The mod only changes the client render/frame limiter; it does not change network packets or server gameplay.
- The JAR must be built with the Ornithe mapping/remapping toolchain. A plain ZIP containing development class files is not a valid distributable mod JAR.
